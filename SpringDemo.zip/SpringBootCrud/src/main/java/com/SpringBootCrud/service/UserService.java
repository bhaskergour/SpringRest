package com.SpringBootCrud.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.SpringBootCrud.bean.User;

@Service
public class UserService {

	private List<User> user = new ArrayList<>(
			Arrays.asList(new User("1", "Anil"), new User("2", "Amit"), new User("3", "Alok")));

	public List<User> getAllUser() {

		return user;
	}

	public void addUser(User newUser) {

		user.add(newUser);
	}

	public User getUser(String id) {
		return user.stream().filter(u -> u.getId().equals(id)).findFirst().get();

	}

}
